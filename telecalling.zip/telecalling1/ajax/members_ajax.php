<?php
include '../db.php';
$member_id=$_POST["member_id"];
$sql="SELECT `member_id`, `member_name`, `member_email`, `member_phone` FROM `members` WHERE `member_id`='".$member_id."'";
$result=$conn->query($sql) ;
$count=$result->num_rows;
$row = $result->fetch_assoc();
if($count>0)
{
$member_id=$row['member_id'];
$member_name=$row['member_name'];
$member_email=$row['member_email'];
$member_phone=$row['member_phone'];
$arr=array("member_id" => $member_id,"member_name" => $member_name,"member_email" => $member_email,"member_phone" => $member_phone);
echo json_encode($arr);
}

?> 

