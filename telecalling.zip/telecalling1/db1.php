<?php

$conn = mysqli_connect("localhost", "shopndto_techninzacrm", "ZuaK0i.*R0Xy", "shopndto_corephpcrm");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>