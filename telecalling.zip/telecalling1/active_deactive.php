<?php
include "db.php";
$member_id=$_REQUEST['member_id'];
$sql=mysqli_query($conn,"SELECT * FROM members WHERE member_id=".$member_id);
$fetch=mysqli_fetch_array($sql);
// print_r($fetch);

if($fetch['crm_access']==1)
{
	$update=mysqli_query($conn,"UPDATE members SET crm_access='0' WHERE member_id=".$member_id); 
	if($update)
	{
		header("location:members.php");
	}

}

if($fetch['crm_access']==0)
{
	$update=mysqli_query($conn,"UPDATE members SET crm_access='1' WHERE member_id=".$member_id);
	if($update)
	{
		header("location:members.php");
	}

}

?>