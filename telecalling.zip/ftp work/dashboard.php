<?php

require('db.php');
include("auth.php"); //include auth.php file on all secure pages ?>
<?php include('header.php') ?>
<section class="dashboard-counts section-padding">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xl-2 col-md-4 col-6">
				<p>Welcome <?php echo $_SESSION['username']; ?>!</p>
			</div>
		</div>
		<div class="row">
			<div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-user"></i></div>
                <div class="name"><strong class="text-uppercase">New Clients</strong><span>Last 7 days</span>
                  <div class="count-number">25</div>
                </div>
              </div>
            </div>
            <!-- Count item widget-->
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-padnote"></i></div>
                <div class="name"><strong class="text-uppercase">Work Orders</strong><span>Last 5 days</span>
                  <div class="count-number">400</div>
                </div>
              </div>
            </div>
            <!-- Count item widget-->
            <div class="col-xl-2 col-md-4 col-6">
              <div class="wrapper count-title d-flex">
                <div class="icon"><i class="icon-check"></i></div>
                <div class="name"><strong class="text-uppercase">New Quotes</strong><span>Last 2 months</span>
                  <div class="count-number">342</div>
                </div>
              </div>
            </div>
		</div>
	</div>
</section>
<?php include('footer.php') ?>    

