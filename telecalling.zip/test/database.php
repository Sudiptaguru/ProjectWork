<?php
$servername = "localhost";
$username = "shopndto_techninzacrm";
$password = "S[,#9&?w*rOY";
$dbname = "shopndto_corephpcrm";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>